import{a as t}from"../chunks/entry.Da1h2znb.js";export{t as start};
