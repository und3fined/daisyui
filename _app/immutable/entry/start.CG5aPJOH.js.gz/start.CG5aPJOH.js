import{a as t}from"../chunks/entry.BvNUmDIb.js";export{t as start};
