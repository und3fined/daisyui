import{a as t}from"../chunks/entry.D5e6nrOF.js";export{t as start};
