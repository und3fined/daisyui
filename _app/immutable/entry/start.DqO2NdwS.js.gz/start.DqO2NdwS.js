import{a as t}from"../chunks/entry.pALI8po5.js";export{t as start};
