import{a as t}from"../chunks/entry.D_HmKAs9.js";export{t as start};
