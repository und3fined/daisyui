import{a as t}from"../chunks/entry.DSGNE1SO.js";export{t as start};
