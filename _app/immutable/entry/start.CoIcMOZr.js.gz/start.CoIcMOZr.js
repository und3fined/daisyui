import{a as t}from"../chunks/entry.aoIyg8G1.js";export{t as start};
