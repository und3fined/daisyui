import{a as t}from"../chunks/entry.ssrIAUmW.js";export{t as start};
