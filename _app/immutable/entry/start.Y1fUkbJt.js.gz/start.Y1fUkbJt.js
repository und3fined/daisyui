import{a as t}from"../chunks/entry.BQBeL_jw.js";export{t as start};
