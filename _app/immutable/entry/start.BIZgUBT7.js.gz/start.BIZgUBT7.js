import{a as t}from"../chunks/entry.Dm4R_emW.js";export{t as start};
