import{a as t}from"../chunks/entry.3EMhC7fP.js";export{t as start};
