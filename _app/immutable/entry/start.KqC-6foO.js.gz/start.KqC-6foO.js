import{a as t}from"../chunks/entry.SBeta-MM.js";export{t as start};
