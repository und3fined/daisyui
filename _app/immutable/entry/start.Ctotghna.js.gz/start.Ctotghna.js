import{a as t}from"../chunks/entry.C5I3hYsK.js";export{t as start};
